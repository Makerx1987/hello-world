﻿using System;

namespace grd
{
    public class syms
	{
		/// <summary>
		/// 名称
		/// </summary>
		public string name;
		/// <summary>
		/// 形状，先列数后行数
		/// </summary>
		public int[] shape;
		/// <summary>
		/// 数据，二维数组
		/// </summary>
		public double[,] data;
		/// <summary>
		/// 改变形状
		/// </summary>
		public void Reshape()
		{

		}
		/// <summary>
		/// 绑定数据来源
		/// </summary>
		/// <param name="arr">一个必须符合data大小的二维数组</param>
		public void Feed(double[,] arr)
		{

		}
		/// <summary>
		/// 图的构造函数
		/// </summary>
		/// <param name="columns">列数</param>
		/// <param name="rows">行数</param>
		/// <param name="cname">名字</param>
		public syms(int columns = 1, int rows = 1, string cname = "")
		{
			name = cname;
			if (columns > 0 && rows > 0) shape = new int[] { columns, rows };
			data = new double[columns, rows];
		}
		/// <summary>
		/// 重载*运算，矩阵乘法
		/// </summary>
		/// <param name="a">图类型</param>
		/// <param name="b">图类型</param>
		/// <returns>一个矩阵乘法的结果图</returns>
		public static syms operator *(syms a, syms b)
		{
			return null;
		}
		/// <summary>
		/// 重载+运算，矩阵加法
		/// </summary>
		/// <param name="a">图类型</param>
		/// <param name="b">图类型</param>
		/// <returns>一个矩阵加法的结果图</returns>
		public static syms operator +(syms a, syms b)
		{
			return null;
		}

		/// <summary>
		/// 重载-运算，矩阵减法
		/// </summary>
		/// <param name="a">图类型</param>
		/// <param name="b">图类型</param>
		/// <returns>一个矩阵减法的结果图</returns>
		public static syms operator -(syms a, syms b)
		{
			return null;
		}

		/// <summary>
		/// 矩阵转置
		/// </summary>
		/// <returns>转置后的矩阵</returns>
		public syms T()
		{
			return null;
		}

		/// <summary>
		/// 矩阵对应乘
		/// </summary>
		/// <param name="a"></param>
		/// <param name="b"></param>
		/// <returns></returns>
		public static syms mul(syms a, syms b)
		{
			return null;
		}

		/// <summary>
		/// 矩阵统统对数
		/// </summary>
		/// <param name="a"></param>
		/// <returns></returns>
		public static syms log(syms a)
		{
			return null;
		}

		/// <summary>
		/// 矩阵加减常数
		/// </summary>
		/// <param name="a"></param>
		/// <returns></returns>
		public syms change(double a)
		{
			return null;
		}

		/// <summary>
		/// 矩阵取反
		/// </summary>
		/// <returns></returns>
		public syms rev()
		{
			return null;
		}

		/// <summary>
		/// 所有元素之和
		/// </summary>
		/// <returns></returns>
		public double sum()
		{
			return 0;
		}
	}
}
