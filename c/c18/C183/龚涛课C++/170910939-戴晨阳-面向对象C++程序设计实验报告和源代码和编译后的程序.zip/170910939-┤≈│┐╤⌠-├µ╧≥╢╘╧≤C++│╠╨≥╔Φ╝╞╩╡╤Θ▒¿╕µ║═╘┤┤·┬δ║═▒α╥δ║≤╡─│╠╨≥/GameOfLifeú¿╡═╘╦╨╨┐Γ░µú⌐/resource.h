//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by GameOfLife.rc
//
#define IDD_GAMEOFLIFE_DIALOG           102
#define IDS_APP_TITLE                   103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDI_SMALL                       108
#define IDC_GAMEOFLIFE                  109
#define IDR_MAINFRAME                   128
#define IDI_ICON1                       129
#define IDI_ICON2                       130
#define ID_START                        1001
#define ID_PAUSE                        1002
#define ID_CONTINUE                     1003
#define ID_STOP                         1004
#define ID_TIMER                        1005
#define IDI_MY                          1006
#define ID_EDIT                         1007
#define ID_S1                           1011
#define ID_S2                           1012
#define ID_S3                           1013
#define ID_S4                           1014
#define ID_S5                           1015
#define ID_S6                           1016
#define ID_S7                           1017
#define ID_S8                           1018
#define ID_D1                           1111
#define ID_D2                           1112
#define ID_D3                           1113
#define ID_D4                           1114
#define ID_D5                           1115
#define ID_D6                           1116
#define ID_D7                           1117
#define ID_D8                           1118
#define ID_TXT1                         1200
#define ID_TXT2                         1201
#define ID_SLOW                         1300
#define ID_FAST                         1301
#define ID_HYPER                        1302
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
